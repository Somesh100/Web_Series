<?php
    $server = "localhost:3306";
    $user = "root";
    $passwd = "Rag@1998";
    $dbname = "db_create";

    $conn = mysqli_connect($server, $user, $passwd, $dbname);
    // if ($conn)
    // {
    //     echo "Connection Successfully Established";
    // }
    // else
    // {
    //     echo "Connection Refused";
    // }
?>