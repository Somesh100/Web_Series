<html>
    <title>
        Playlists
    </title>
    
    <head>
        <link rel=stylesheet type=text/css href="playlist.css">
    </head>
</html>

<style>
    body
    {
          background-image: url('./images/backg3.jpg');
    }
	h1
	{
		color:white;
	}
	head
	{
		color:green;
		float:left;
	}
	welcome
	{
		float:left;
	}

    .parent
    {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: space_between;
        align-items: center;
    }
    .dropdown{
        position: relative;
        width: 80px;
        height: 50px;
    }
   
	.part
    {
        margin: 10px;
        width: 32%;
        border-radius: 4px;
        display: block;
        background-color:#194A8D;
    }
    .p1
    {
		text:bold;
        color: white;
    }
    .p2
    {
        color: red;
    }
    .sear
    {
        width: 30%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 2px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    .btnsear
    {
		color:white;
		font-weight:bold;
        width: 10%;
        background-color: blue;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 2px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    .btnsear:hover
    {
        background-color: red;
    }
</style>

<?php
    session_start();
    if (!isset($_SESSION['uname']))
    {
        header("location:login.html?val=firstlogin");
    }
    include_once("db_conn.php");
    echo "<body>";
    echo "<div class=topnav>";
    echo "<a class=active href=logout.php> Logout </a>";
    echo "<a href=register.html?user=user> Add User </a>";
    if ($_SESSION['type'] == 'admin')
    {
        echo "<a href=welcome.html>Upload Video</a>";
    }
    echo "<a class=uname href=#>".$_SESSION['uname']."</a>";
    echo "<div class=dropdown>";
	echo "<a href=#>Welcome</a>";
    echo "</div>";
    echo "</div>";
    echo "<center>";
    echo "<form name=sbar action=playlist.php method=post>";
    echo "<input name=search class=sear type=text placeholder=Search..>";
    echo "<input name=btn class=btnsear type=submit value=Search>";
    echo "</center>";
	echo"<h1>All Movies</h1>";
    echo "</form>";
    if (isset($_POST['btn']))
    {
        $db_query = mysqli_query($conn, "select * from web_series where ws_name like '%".$_POST['search']."%'");
    }
    else
    {
        $db_query = mysqli_query($conn, "select * from web_series");
    }
    echo "<div class=parent>";
    while ($rows = mysqli_fetch_assoc($db_query))
    {
        $name = $rows['ws_name'];
        $genre = $rows['ws_genre'];
        $no_of_seasons = $rows['no_of_seasons'];
        $no_of_episodes = $rows['no_of_episodes'];
        $duration = $rows['duration'];
        $ratings = $rows['ratings'];
        $pub_date = $rows['pub_date'];
        $img = './images/'.$rows['ws_image'];
        $vid = './videos/'.$rows['ws_video'];
        echo "<div class=part>";
        echo "<video width=480 height=180 poster='$img' controls>";
        echo "<source src='$vid' type=video/mp4>";
        echo "</video>";
        echo "<p>";
        echo "<div class=p1> Name:            </div> <div class=p2>$name           </div> <br>";
        echo "<div class=p1> Genre:           </div> <div class=p2>$genre          </div> <br>";
        echo "<div class=p1> No. of seasons:  </div> <div class=p2>$no_of_seasons  </div> <br>";
        echo "<div class=p1> No. of episodes: </div> <div class=p2>$no_of_episodes </div> <br>";
        echo "<div class=p1> Duration:        </div> <div class=p2>$duration       </div> <br>";
        echo "<div class=p1> Ratings:         </div> <div class=p2>$ratings        </div> <br>";
        echo "<div class=p1> Published Date:  </div> <div class=p2>$pub_date       </div> <br>";
        echo "</p>";
        echo "</div><br>";
    }
    echo "</div>";
    echo "</body>";
?>